"""Draw the two survey schematics with method-focused labels."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon

ROOT = Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family': 'DejaVu Sans', 'pdf.fonttype': 42})
INK = '#203947'


def save_new(fig, name, title):
    target = ROOT / 'figures' / name
    if target.exists():
        raise SystemExit(f'Refusing to replace existing figure: {target}')
    fig.savefig(target, metadata={'Title': title, 'Author': 'Survey authors'})
    plt.close(fig)
    print(target)


fig, ax = plt.subplots(figsize=(7.05, 3.7))
fig.subplots_adjust(0, 0, 1, 1)
ax.set(xlim=(0, 1), ylim=(0, 1))
ax.axis('off')
panels = [(0.005, 0.308, '#F1F6FB', '#427CAA', 'A  Tasks and stages'),
          (0.328, 0.308, '#F5F2FA', '#8469AD', 'B  Efficiency hierarchy'),
          (0.651, 0.344, '#F1F7F4', '#46896F', 'C  This survey')]
for x, w, bg, color, title in panels:
    ax.add_patch(FancyBboxPatch((x, .025), w, .95, boxstyle='round,pad=0.004,rounding_size=0.018', lw=.6, ec='#BAC8CC', fc=bg))
    ax.text(x+.013, .935, title, color=color, size=9, weight='bold', va='center')


def box(x, y, w, h, label, color, size=8.7):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.005,rounding_size=0.008', lw=.7, ec=color, fc='white'))
    ax.text(x+w/2, y+h/2, label, color=INK, size=size, ha='center', va='center', linespacing=1.35)


for i, label in enumerate(['Input modalities', 'Motion planning', 'Video generation', 'Refinement', 'Output / evaluation']):
    y=.76-i*.128
    box(.038, y, .242, .085, label, '#7C9DBB')
    if i<4:
        ax.annotate('', xy=(.159, y-.04), xytext=(.159, y-.006), arrowprops=dict(arrowstyle='->', color='#7C9DBB', lw=.8))
ax.text(.159, .085, 'Human Motion Video\nGeneration', ha='center', va='center', size=8, color='#596F7E')
for y, label in [(.67,'Algorithms\nSampling and model changes'),(.45,'Systems\nExecution and resources'),(.23,'Frameworks\nImplementation support')]:
    box(.361, y, .242, .135, label, '#9581B5',8.3)
ax.text(.482, .085, 'Efficient Diffusion Models', ha='center', va='center', size=8, color='#596F7E')
ax.text(.668, .845, '1  Method families', size=8.5, weight='bold', color=INK)
box(.674,.681,.142,.107,'GAN\nDiffusion', '#76A58F',8.3)
box(.830,.681,.142,.107,'Visual AR\nRendering', '#76A58F',8.3)
ax.text(.668,.596,'2  Fast and Stable',size=8.5,weight='bold',color=INK)
box(.674,.431,.298,.115,'Fast: computation and runtime\nStable: consistency over time', '#76A58F',8.2)
ax.text(.668,.346,'3  Practical comparison',size=8.5,weight='bold',color=INK)
box(.674,.165,.298,.13,'Tasks and module roles\nRuntime and GPU memory\nTemporal quality and failures', '#76A58F',8.0)
ax.text(.823,.073,'Connecting design with deployment',ha='center',va='center',size=7.4,color='#596F7E')
save_new(fig, 'fig_survey_perspectives_measurement.pdf', 'Survey perspectives: methods, Fast and Stable, practical comparisons')

fig, ax = plt.subplots(figsize=(7.05, 3.8))
fig.subplots_adjust(0, 0, 1, 1)
ax.set(xlim=(0, 1), ylim=(0, 1))
ax.axis('off')
ax.text(.018,.95,'Primary route follows the first matching generation path',size=10,weight='bold',color=INK)


def node(x, y, w, h, label, edge='#536B78', bg='#F6F8F9', size=8.7):
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.004,rounding_size=0.008',lw=.65,ec=edge,fc=bg))
    ax.text(x,y,label,ha='center',va='center',size=size,color=edge,weight='bold')


def arrow(start,end,color='#536B78'):
    ax.annotate('',xy=end,xytext=start,arrowprops=dict(arrowstyle='->',color=color,lw=.7,shrinkA=1,shrinkB=1))


node(.091,.67,.157,.15,'RGB system\n+ documented\narchitecture',size=8.4)
centers=[.281,.478,.675,.872]
labels=['Geometric\nappearance\nreuse?', 'AR state +\nlocal\nemission?', 'Iterative\nvisual\ndenoising?', 'Adversarial\nfeed-forward\nsynthesis?']
routes=['Rendering','Visual AR','Diffusion','GAN']
colors=['#509C84','#8B75BB','#4B8CCA','#B68A32']
fills=['#E3F1E9','#E9E3F3','#E1EFF8','#F9EFD5']
half_w=.087
half_h=.125
arrow((.172,.67),(centers[0]-half_w,.67))
for i,(x,label,route,color,bg) in enumerate(zip(centers,labels,routes,colors,fills)):
    ax.add_patch(Polygon([(x-half_w,.67),(x,.67+half_h),(x+half_w,.67),(x,.67-half_h)],closed=True,fc=bg,ec=INK,lw=.65))
    ax.text(x,.67,label,ha='center',va='center',size=8.4,color=INK,weight='bold')
    ax.text(x,.835,str(i+1),ha='center',va='center',size=8,color=color,bbox=dict(boxstyle='circle,pad=0.1',ec=color,fc='white',lw=.65))
    node(x,.402,.151,.098,route,color,bg,size=9.1)
    arrow((x,.67-half_h),(x,.454),color)
    ax.text(x+.01,.493,'Yes',size=7.5,color=color)
    if i<3:
        arrow((x+half_w,.67),(centers[i+1]-half_w,.67))
        ax.text(x+.101,.694,'No',size=7.2,color='#536B78',ha='center')
ax.plot([.091,.091,.542],[.591,.219,.219],color='#536B78',lw=.65)
arrow((.526,.219),(.545,.219))
ax.text(.107,.245,'Architecture unspecified or outside scope',size=7.3,color='#536B78')
node(.723,.219,.346,.095,'Outside primary comparison',size=8.5)
ax.plot([.961,.987,.987,.902],[.67,.67,.219,.219],color='#536B78',lw=.65)
arrow((.918,.219),(.901,.219))
ax.text(.971,.694,'No',size=7.2,color='#536B78',ha='center')
ax.plot([.018,.985],[.117,.117],color='#B9C7CF',lw=.5)
ax.text(.018,.07,'Also describe',size=7.5,color='#536B78',weight='bold')
for x,label in [(.288,'Representation'),(.505,'Temporal state'),(.719,'Sampling / training'),(.92,'Personalization')]:
    ax.text(x,.07,label,ha='center',size=7.5,color='#536B78')
save_new(fig, 'fig_ownership_routes.pdf', 'Visual-generation route assignment')
