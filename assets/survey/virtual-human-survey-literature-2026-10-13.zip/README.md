# 文献补充版综述

日期：2026-10-13。基于上一轮测量准备版选择性补充 26 篇文献，共引用 263 篇，PDF 55 页。此前版本保留在原目录。

- `main.pdf`：阅读稿。
- `main.tex`、`sec_new/`、`bib/`、`figures/`：完整论文源码。
- `REVISION_REPORT.md`：修改、理由、采用文献和检查结果。
- `measurements/`：统一实测约定与空模板，等待作者提供数值。

使用正常 TeX Live 环境运行 `python3 revision/build_pdf.py`，脚本在新的临时目录中完成四轮 LaTeX 和 BibTeX 编译，不覆盖源码或已有 PDF。也可以将源码包导入 Overleaf，以 `main.tex` 为入口。
