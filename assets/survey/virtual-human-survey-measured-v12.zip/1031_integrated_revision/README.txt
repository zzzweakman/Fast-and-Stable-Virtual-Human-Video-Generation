1031 图文整合版 v4（2026-10-31）

本版从分类图移除 Dense conditioned video，并改成上下两排：
上排 GAN / Rendering，各四组；下排 Diffusion / Visual AR，各三组，逐行对齐。
分类图共 14 个精选机制组，保留深色粗体方法名和 Fast/Stable 说明。
完整 136 方法树图、机构图标、两种连线及加粗的 caption 说明继续保留，图内没有灰色附注。

交付文件
main.pdf：46 页。树图在第 4 页，分类图在第 6 页，压缩后的条件生成背景段从第 14 页开始。
authoring/overview_main.pptx：两幅正文图的可编辑 PowerPoint。
figures/02_timeline.pdf、figures/taxonomy_classification.pdf：正文矢量图及同名 PNG 预览。
integration_review/CHANGES_AND_REVIEW.txt：本次图文修改与证据范围。
integration_review/figure_citation_audit.csv：136 个方法的引用映射。

正文与引用
基础条件生成方法作为历史背景简要介绍；Diffused Heads、Loopy、MEMO 的状态讨论移入 Stable 小节。
移除图中栏目不等于删去论文或否定所有长视频能力。EMO、MultiTalk 已有延长视频的设计或展示，正文明确区分它们与经过验证的实时、稳定长时部署。
全部 304 个 BibTeX 键及 293 个正文引用键保留，136 个图示方法都有正文引用，实验表与 1030 底稿逐字节一致。
原目录中的 15 个历史机制分组保留作映射，正文分类图只选其中 14 组；不把背景方法改归到其他主路线。

构建
  sh build.sh
  python authoring/build_figures.py
  python authoring/audit_and_catalogue.py
论文使用常规 TeX Live / MiKTeX，图稿脚本依赖 python-pptx、reportlab、pymupdf。
分类图使用 authoring/fonts/ 中附带许可的 DejaVu Sans；树图保留原稿字体和图标。
本版打包为 survey_1031_integrated_revision_v4.zip；v3 文件继续保存在 _v3.zip 中。
用户原始输入保存在 authoring/inputs/，原目录文件未覆盖。
