分类参考文献整理说明（2026-10-30）

本包已按本次收到的最新版 ours(1).zip 整理，并已接入本次修订论文的 main.tex。
不是直接修改用户上传的原ZIP：原文件保持不变，修改位于新修订副本。

文件
bib/GAN.bib                 28条
bib/Diffusion.bib           73条
bib/Rendering.bib           81条
bib/Visual_AR.bib            5条
bib/Shared_References.bib   117条
合计304个唯一citation key：原稿280条全部保留，真正新增24条。
Shared收纳理论、基础模型、数据集、指标、纯运动/对话控制、辅助研究与尚不宜强行归入视觉owner的边界引用；它不是第五种视觉生成路线。

末尾新增批次
每个类别文件末尾均设 NEW_BATCH_2026_10_30_BEGIN / END 注释块。
本批末尾共27条：25个本次新增图示方法 + FastTalk/GANimate两条新提供的期刊引用。
其中24条是原稿没有的NEW_BIB_KEY；StyleMask、HyperReenact、MultiTalk三条原稿已有，标为NEW_TO_FIGURE_EXISTING_BIB，移动到末尾一次，未重复新增。
其余11条上传的既有引用在原有相对顺序中复核/更新，以UPDATED_METADATA或REVIEWED_METADATA注释说明。

分类与元数据
按主视觉生成owner而非训练损失/文件旧名归类。DINet、IP-LAP、EDTalk、EAT、FixTalk、RAM-Avatar迁入Rendering；纯motion AR不自动归入Visual_AR。
图示136条使用本轮审查结果；未进入图的其他历史方法若保留原类别，逐条注明继承最新稿位置、并非重新逐篇全文审查。
修正MakeItTalk标题的I/l拼写，保留原key zhou2020makelttalk。
SoulX-FlashTalk、Hallo3、LatentSync使用与图示年份一致的历史v1标题/作者/版本链接；后期显示别名写入注释，citation key与年份不变。
Yu与Cho两篇GaussianTalker是不同论文，两条都保留；图示对应Cho/Korea University。
优先采用已核验DBLP身份/元数据；没有独立取得DBLP导出的记录使用官方论文/出版方信息，不将全部引用宣称为DBLP原始导出。

如何接入BibTeX论文
保留原稿bibliographystyle；只加载本包五个分类文件：
\bibliography{bib/GAN,bib/Diffusion,bib/Rendering,bib/Visual_AR,bib/Shared_References}
不能同时加载原来的intro/diffusion/AR/render等旧文件，否则会产生重复key。
Bib文件中的物理顺序用于人工维护；文末参考文献最终顺序仍由bst样式决定。

append_only_24_new_keys.bib是单独的安全增量参考文件，只适合把24条真正新key合并到另一份尚未采用完整五文件的论文。不要与完整五文件同时加载。
citation_manifest.json记录每条key的分类、原文件、批次状态与证据深度。
batch_27_manifest.json列出末尾27条；metadata_changes.json记录元数据调整。
