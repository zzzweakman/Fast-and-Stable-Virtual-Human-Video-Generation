#!/bin/sh
set -eu
cd "$(dirname "$0")"
target="${1:-main}"
# Explicit map loading also supports Latin Modern supplied through TEXMFHOME.
pdflatex -interaction=nonstopmode -halt-on-error -jobname="$target" "\pdfmapfile{+lm.map}\input{$target.tex}"
bibtex "$target"
pdflatex -interaction=nonstopmode -halt-on-error -jobname="$target" "\pdfmapfile{+lm.map}\input{$target.tex}"
pdflatex -interaction=nonstopmode -halt-on-error -jobname="$target" "\pdfmapfile{+lm.map}\input{$target.tex}"
