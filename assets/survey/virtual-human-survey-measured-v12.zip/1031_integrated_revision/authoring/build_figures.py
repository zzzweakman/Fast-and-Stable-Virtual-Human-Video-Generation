"""Preserve the original timeline and build a representative mechanism chart.

Run from any directory: python authoring/build_figures.py
Dependencies: python-pptx, reportlab, pymupdf. Fonts are bundled in fonts/.
The full-catalogue originals are preserved in inputs/.
"""
from pathlib import Path
from collections import Counter
from copy import deepcopy
import json
import pymupdf as fitz
from pptx import Presentation
from pptx.util import Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIG = ROOT / 'figures'
W, H = 510, 417
COLORS = {'GAN':'A57936', 'Rendering':'467D9F', 'Diffusion':'377F88', 'Visual AR':'85669E'}
INK = '253340'
RECORDS = json.loads((HERE / 'catalogue_136.json').read_text())['records']
BY_NAME = {r['method']:r for r in RECORDS}
# Exact group names are retained in the mapping; shorter display labels fit print.
GROUPS = {
 'GAN': [
  ('Structured controls',['PC-AVS','Audio-to-Visual Diffusion Priors'],'Compact motion controls','Control leakage and jitter'),
  ('Regional synthesis',['MuseTalk','FastTalk'],'Restrict the synthesized region','Crop seams and framewise flicker'),
  ('Personalized synthesis',['Live Speech Portraits','GANimate'],'Reuse enrolled appearance','Controller or latent-search variation'),
  ('Codebooks and detail retrieval',['FlowVQTalker'],'Predict compact visual codes','Quantization and detail consistency')],
 'Rendering': [
  ('Parametric geometry and UV features',['StyleAvatar','RAM-Avatar'],'Reuse geometry and UV features','Tracking and deformation error'),
  ('Implicit appearance transport',['LivePortrait','DINet'],'Warp persistent source features','Occlusion and identity leakage'),
  ('Neural radiance fields',['AD-NeRF','ER-NeRF'],'Accelerate field queries','Geometry and expression mismatch'),
  ('Gaussian scenes',['FlashAvatar','LAM'],'Rasterize compact primitives','Deformation error and floaters')],
 'Diffusion': [
  ('Few-step and one-step sampling',['FADA','TurboTalk'],'Reduce sampler evaluations','Temporal consistency after distillation'),
  ('Streaming denoising',['Live Avatar','SoulX-FlashTalk'],'Chunk execution and cache reuse','Chunk boundaries and history drift'),
  ('Temporal state and recovery',['MEMO','InfiniteTalk'],'Limit repeated context processing','Anchoring and recovery from drift')],
 'Visual AR': [
  ('Joint video–motion tokens',['UniMo'],'Share a compact token sequence','Alignment and error propagation'),
  ('Causal visual state + local emission',['Body of Her','MIDAS'],'Reuse history; emit frames locally','Cache policy and recurrent drift'),
  ('Phoneme-guided keyframes',['AvatarSync'],'Sparse keyframes plus interpolation','Interpolation flicker; causality limits')],
}

def rgb(v): return tuple(int(v[i:i+2],16)/255 for i in (0,2,4))
def tint(v, f=.92): return ''.join(f'{round(c*255*(1-f)+255*f):02X}' for c in rgb(v))
for name,filename in [('DV','DejaVuSans.ttf'),('DVB','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(HERE/'fonts'/filename)))

class Scene:
    def __init__(self): self.ops=[]
    def rect(self,x,y,w,h,fill,stroke=None,lw=.5,r=0): self.ops.append(('rect',locals().copy()))
    def line(self,x,y,x2,y2,color,lw=.6): self.ops.append(('line',locals().copy()))
    def poly(self,points,color,lw=1,fill=None): self.ops.append(('poly',locals().copy()))
    def text(self,x,y,w,h,text,size=8,color=INK,bold=False,align='left'):
        font='DVB' if bold else 'DV'
        for line in text.split('\n'):
            assert pdfmetrics.stringWidth(line,font,size) <= w+.5, (text,w,size,pdfmetrics.stringWidth(line,font,size))
        assert x>=0 and y>=0 and x+w<=W+.1 and y+h<=H+.1, (text,x,y,w,h)
        self.ops.append(('text',locals().copy()))
    def render(self,pdf_path,slide):
        c=canvas.Canvas(str(pdf_path),pagesize=(W,H))
        c.setTitle(pdf_path.stem.replace('_',' '))
        c.setAuthor('Virtual-human survey authors')
        for kind,a in self.ops:
            if kind=='rect':
                x,y,w,h=a['x'],a['y'],a['w'],a['h']
                c.setFillColorRGB(*rgb(a['fill'])); c.setLineWidth(a['lw'])
                if a['stroke']:c.setStrokeColorRGB(*rgb(a['stroke']))
                c.roundRect(x,H-y-h,w,h,a['r'],fill=1,stroke=int(bool(a['stroke'])))
                sh=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if a['r'] else MSO_SHAPE.RECTANGLE,Pt(x),Pt(y),Pt(w),Pt(h))
                if a['r']:sh.adjustments[0]=.08
                sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(a['fill'])
                if a['stroke']:sh.line.color.rgb=RGBColor.from_string(a['stroke']);sh.line.width=Pt(a['lw'])
                else:sh.line.fill.background()
            elif kind=='line':
                c.setStrokeColorRGB(*rgb(a['color']));c.setLineWidth(a['lw']);c.line(a['x'],H-a['y'],a['x2'],H-a['y2'])
                sh=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Pt(a['x']),Pt(a['y']),Pt(a['x2']),Pt(a['y2']))
                sh.line.color.rgb=RGBColor.from_string(a['color']);sh.line.width=Pt(a['lw'])
            elif kind=='poly':
                pts=a['points'];p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1])
                for x,y in pts[1:]:p.lineTo(x,H-y)
                if a['fill']:p.close();c.setFillColorRGB(*rgb(a['fill']))
                c.setStrokeColorRGB(*rgb(a['color']));c.setLineWidth(a['lw']);c.drawPath(p,stroke=1,fill=bool(a['fill']))
                b=slide.shapes.build_freeform(pts[0][0],pts[0][1],scale=12700)
                b.add_line_segments(pts[1:],close=bool(a['fill']));sh=b.convert_to_shape()
                sh.line.color.rgb=RGBColor.from_string(a['color']);sh.line.width=Pt(a['lw'])
                if a['fill']:sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(a['fill'])
                else:sh.fill.background()
            else:
                c.setFillColorRGB(*rgb(a['color']));c.setFont('DVB' if a['bold'] else 'DV',a['size'])
                for j,line in enumerate(a['text'].split('\n')):
                    by=H-a['y']-a['size']*.94-j*a['size']*1.2
                    if a['align']=='center':c.drawCentredString(a['x']+a['w']/2,by,line)
                    else:c.drawString(a['x'],by,line)
                sh=slide.shapes.add_textbox(Pt(a['x']),Pt(a['y']),Pt(a['w']),Pt(a['h']))
                tf=sh.text_frame;tf.clear();tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
                tf.vertical_anchor=MSO_ANCHOR.TOP;tf.word_wrap=False
                for j,line in enumerate(a['text'].split('\n')):
                    p=tf.paragraphs[0] if j==0 else tf.add_paragraph();p.text=line
                    p.font.name='DejaVu Sans';p.font.size=Pt(a['size']);p.font.bold=a['bold'];p.font.color.rgb=RGBColor.from_string(a['color'])
                    p.space_before=Pt(0);p.space_after=Pt(0);p.line_spacing=1.0
                    p.alignment=PP_ALIGN.CENTER if a['align']=='center' else PP_ALIGN.LEFT
        c.showPage();c.save()

def label(name): return BY_NAME[name].get('display_name',name)

def taxonomy():
    s=Scene()
    for route,x,y in [('GAN',0,0),('Rendering',263,0),('Diffusion',0,240),('Visual AR',263,240)]:
        color=COLORS[route];w=247
        s.text(x+2,y+1,w-4,19,route,12,color,True)
        s.line(x,y+20,x+w,y+20,color,1.1)
        for j,(group,names,cost,state) in enumerate(GROUPS[route]):
            yy=y+25+j*51
            s.rect(x,yy,w,48,'FFFFFF',tint(color,.35),.5,r=1.2)
            s.rect(x+.5,yy+.5,w-1,13,tint(color),r=1)
            title=group.replace('Joint video–motion','Joint video-motion')
            s.text(x+5,yy+1.3,w-10,12,title,8.6,color,True)
            s.text(x+5,yy+15,w-10,11,' / '.join(label(n) for n in names),8.0,'17232E',True)
            s.text(x+5,yy+26,w-10,10,'Fast: '+cost,7.5,'3F4C57')
            s.text(x+5,yy+36,w-10,10,'Stable: '+state,7.5,'3F4C57')
    return s

def restored_tree():
    """Retain every original icon and branch style; move the legend to the caption."""
    src=HERE/'inputs'
    prs=Presentation(src/'chronology_template.pptx')
    for sh in list(prs.slides[0].shapes):
        if sh.name.startswith('runtime-key'):
            el=sh._element;el.getparent().remove(el)
    prs.slide_height=Pt(1122)
    doc=fitz.open(src/'timeline.pdf')
    doc[0].set_cropbox(fitz.Rect(0,0,doc[0].rect.width,1120))
    doc.save(FIG/'02_timeline.pdf',garbage=4,deflate=True)
    return prs


def main():
    FIG.mkdir(exist_ok=True)
    prs=restored_tree()
    for route,groups in GROUPS.items():
        for group,names,_,_ in groups:
            for name in names:
                assert BY_NAME[name]['primary_route']==route and BY_NAME[name]['mechanism_group']==group
    # Build the mechanism chart in its native print dimensions, then scale its
    # editable shapes onto the original deck's common canvas.
    chart_prs=Presentation();chart_prs.slide_width=Pt(W);chart_prs.slide_height=Pt(H)
    chart_slide=chart_prs.slides.add_slide(chart_prs.slide_layouts[6])
    taxonomy().render(FIG/'taxonomy_classification.pdf',chart_slide)
    target=prs.slides[1]
    for sh in list(target.shapes):
        el=sh._element;el.getparent().remove(el)
    factor=min(prs.slide_width/Pt(W),(prs.slide_height-Pt(12))/Pt(H))
    dx=(prs.slide_width-Pt(W)*factor)/2
    dy=(prs.slide_height-Pt(H)*factor)/2
    for shape in chart_slide.shapes:
        el=deepcopy(shape._element);target.shapes._spTree.insert_element_before(el,'p:extLst')
    for sh in target.shapes:
        sh.left=round(sh.left*factor+dx);sh.top=round(sh.top*factor+dy)
        sh.width=round(sh.width*factor);sh.height=round(sh.height*factor)
        if sh.line.width is not None:sh.line.width=round(sh.line.width*factor)
        if sh.has_text_frame:
            for para in sh.text_frame.paragraphs:
                if para.font.size is not None:para.font.size=round(para.font.size*factor)
                for run in para.runs:
                    if run.font.size is not None:run.font.size=round(run.font.size*factor)
    prs.slides[0].notes_slide.notes_text_frame.text=(
        'Complete 136-method timeline in the main paper. Original institution icons and solid/dashed branch styles retained. '
        'Solid: claimed real-time performance. Dashed: real-time capability not reported. '
        'These inherited annotations use heterogeneous timing boundaries and hardware; this layout revision does not re-audit speed. '
        'The figure caption carries the legend. Years follow cited editions; branches do not establish inheritance.\n'+
        '\n'.join(r['method']+' -> '+r['citation_key'] for r in RECORDS))
    target.notes_slide.notes_text_frame.text=(
        'Representative methods for 14 selected mechanism groups; examples are not exhaustive. '
        'GAN and Rendering form the upper row; Diffusion and Visual AR each have three aligned groups below. '
        'Dense conditioned video is discussed as historical background in the main text. '
        'Method names use bold dark text; Fast/Stable descriptions use regular text. '
        'Fast indicates a computation lever and Stable a temporal-state issue or design target. '
        'The figure caption explains these terms. No gray header/footer notes are part of the artwork.')
    prs.save(HERE/'overview_main.pptx')
    for name in ['02_timeline','taxonomy_classification']:
        doc=fitz.open(FIG/(name+'.pdf'))
        zoom=min(2,1800/doc[0].rect.width)
        doc[0].get_pixmap(matrix=fitz.Matrix(zoom,zoom),alpha=False).save(FIG/(name+'.png'))
    (HERE/'figure_method_map.json').write_text(json.dumps({
        'timeline_count':136,'timeline_route_counts':dict(Counter(r['primary_route'] for r in RECORDS)),
        'timeline':RECORDS,'taxonomy':GROUPS,'taxonomy_scope':'Representative examples from 14 selected mechanism groups',
        'taxonomy_background_omissions':['Dense conditioned video'],
        'placement':'Both figures appear in the main paper',
        'branch_styles':'Original solid/dashed assignments retained; legend moved to caption'
    },ensure_ascii=False,indent=2)+'\n')
    print('Built main-paper timeline with all 136 methods, original icons and two branch styles; cleaned representative mechanism chart.')

if __name__=='__main__':main()
