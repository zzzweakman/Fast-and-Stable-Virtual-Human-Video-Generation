"""Validate figure/reference integration and write the method-reference CSV."""
from pathlib import Path
from collections import Counter, defaultdict
import csv, json, re, zipfile
from pptx import Presentation

ROOT=Path(__file__).resolve().parents[1]
AUTHORING=ROOT/'authoring'
OUT=ROOT/'integration_review'
OUT.mkdir(exist_ok=True)

def bib_entries(path):
    text=path.read_text();out=[]
    for m in re.finditer(r'@([A-Za-z]+)\s*\{\s*([^,\s]+)\s*,',text):
        start=m.end();depth=1;quoted=False;i=start
        while i<len(text) and depth:
            ch=text[i]
            if ch=='\\':i+=2;continue
            if ch=='{':depth+=1
            elif ch=='}':depth-=1
            i+=1
        assert depth==0, (path,m.group(2),'unbalanced entry')
        body=text[start:i-1];fields={};p=0
        while p<len(body):
            f=re.search(r'([A-Za-z][\w-]*)\s*=\s*',body[p:])
            if not f:break
            key=f.group(1).lower();a=p+f.end();b=a
            if body[a:a+1]=='{':
                b=a+1;d=1
                while b<len(body) and d:
                    if body[b]=='\\':b+=2;continue
                    if body[b]=='{':d+=1
                    elif body[b]=='}':d-=1
                    b+=1
                val=body[a+1:b-1]
            elif body[a:a+1]=='"':
                b=a+1
                while b<len(body) and body[b]!='"':
                    b+=2 if body[b]=='\\' else 1
                b+=1;val=body[a+1:b-1]
            else:
                b=body.find(',',a)
                if b<0:b=len(body)
                val=body[a:b].strip()
            fields[key]=val;p=b+1
        out.append({'key':m.group(2),'type':m.group(1).lower(),'file':str(path.relative_to(ROOT)),**fields})
    return out

def active_tex(path,seen=None):
    seen=set() if seen is None else seen
    if path in seen:return ''
    seen.add(path)
    text=re.sub(r'(?<!\\)%[^\n]*','',path.read_text())
    for m in list(re.finditer(r'\\input\{([^}]+)\}',text))[::-1]:
        p=ROOT/(m.group(1)+('.tex' if not m.group(1).endswith('.tex') else ''))
        text=text[:m.start()]+active_tex(p,seen)+text[m.end():]
    return text

def cites(text):
    return set(k.strip() for m in re.finditer(r'\\cite[a-zA-Z]*\*?(?:\[[^\]]*\])*\{([^}]+)\}',text) for k in m.group(1).split(','))

def main():
    entries=[e for p in sorted((ROOT/'bib').glob('*.bib')) for e in bib_entries(p)]
    keys=[e['key'] for e in entries];keymap={e['key']:e for e in entries}
    assert len(keys)==len(set(keys))==304
    body=active_tex(ROOT/'main.tex');used=cites(body)
    assert not used-set(keys), sorted(used-set(keys))
    records=json.loads((AUTHORING/'catalogue_136.json').read_text())['records']
    selected=json.loads((AUTHORING/'figure_method_map.json').read_text())
    batch=json.loads((ROOT/'bibliography_notes/batch_27_manifest.json').read_text())
    new25={'tripathy2021facegan','meshry2021lsr','min2022styletalker','bounareli2022directions','bounareli2023stylemask','bounareli2023hyperreenact','yu2023probabilistic','shen2023difftalk','stypulkowski2024diffusedheads','karras2023dreampose','wang2024disco','xu2024magicanimate','wei2024aniportrait','xie2024xportrait','wang2024vexpress','xu2024hallo','chen2025echomimic','jiang2024loopy','cui2024hallo3','zheng2024memo','mukhopadhyay2024diff2lip','li2024latentsync','wang2025fantasytalking','gan2025omniavatar','DBLP:conf/nips/KongGZKWCCL25'}
    fresh={
      'yu2023probabilistic':('Primary method PDF, p.4; prior source also records appendix','Diffusion supplies non-lip motion; modulated-convolution adversarial generator supplies RGB.'),
      'liu2026fasttalk':('Primary full-text, Method 2.1 and 2.4','One-step regional latent restoration with adversarial training; pretrained diffusion weights do not make inference a diffusion sampler.'),
      'fenakel2026ganimate':('Primary full-text, experiments and limitations','StyleGAN latent optimization; reported 0.5 s/frame at 1024 square on RTX 2080 Ti. Retain as background/personalization example, not a real-time demonstration.'),
      'zhang2023dinet':('Primary method PDF, Method and Fig.2','Deform source appearance features before inpainting; Rendering under this survey ownership rule.'),
      'zhong2023identity':('Primary method PDF, Sec.3.2.1','Predict motion fields and warp reference images/features; Rendering.'),
      'gan2023eat':('Primary method PDF, Fig.3 and Sec.3','RePos-Net predicts 3D flow to transform source appearance; Rendering.'),
      'tan2024edtalk':('Primary paper plus official networks/styledecoder.py, ToFlow and Synthesis','grid_sample transports source features before RGB decoding; Rendering. Code inspected, not executed.'),
      'tan2025fixtalk':('Primary method PDF, Sec.3.1 and Fig.4; architectural-inheritance inference','Retains EDTalk generator while modifying motion/detail inputs; medium-confidence paper inference, not direct FixTalk code verification.'),
      'deng2024ramavatar':('Primary method PDF, neural-texture method','Rasterized neural textures on parametric geometry feed image decoding; Rendering despite adversarial decoder training.'),
      'hu2025unitalker':('Primary method PDF, Sec.4.3.2','AR speech/landmark controller feeds an EchoMimic denoising U-Net; Diffusion owns RGB.'),
      'deng2026fluentavatarflickerfreetalkingheadanimation':('Primary v1 full-text, Method and keyframe interpolation','Visual-token keyframes support Visual AR placement; parallel prediction and interpolation do not establish fully causal streaming.'),
    }
    routefile={'GAN':'GAN','Diffusion':'Diffusion','Rendering':'Rendering','Visual AR':'Visual_AR'}
    rows=[]
    selected_keys={r['citation_key'] for r in selected['timeline']}
    for r in records:
        k=r['citation_key'];e=keymap[k]
        assert int(e['year'])==r['cited_edition_year'], (k,e['year'],r['cited_edition_year'])
        assert e['file']=='bib/'+routefile[r['primary_route']]+'.bib', (k,e['file'],r['primary_route'])
        assert k in used, ('figure method not cited in main text',k)
        depth,decision=fresh.get(k,('Primary abstract/edition metadata revisited; detailed classification evidence inherited from supplied audit',r.get('classification_evidence','')) if k in new25 else ('Supplied classification audit retained; not freshly re-audited in full',r.get('classification_evidence','')))
        rows.append({'method':r['method'],'display_name':r['display_name'],'citation_key':k,'cited_year':r['cited_edition_year'],'primary_route':r['primary_route'],'mechanism_group':r['mechanism_group'],'main_timeline':k in selected_keys,'cited_in_main':k in used,'bibliography_file':e['file'],'review_depth_in_1031_integration':depth,'decision_and_limits':decision,'primary_sources':' | '.join(r.get('source_urls',[])),'speed_encoding':'Original solid/dashed assignments retained; inherited source annotations, not a new speed audit','long_horizon_claim':'Figure inclusion does not certify sustained stability'})
    assert len(rows)==136 and len({r['citation_key'] for r in rows})==136
    normalize=lambda s:re.sub(r'[^a-z0-9]','',s.lower())
    expected={normalize(r['display_name']):r for r in records}
    ppt=Presentation(AUTHORING/'inputs/chronology_template.pptx')
    for i,slide in enumerate(ppt.slides):
        shapes=[s for s in slide.shapes if s.has_text_frame and s.text and (s.name.startswith('method-') if i==0 else s.name.startswith('Representative '))]
        actual={normalize(s.text):s for s in shapes}
        assert len(shapes)==136 and set(actual)==set(expected)
        if i==1:
            groups=[s for s in slide.shapes if s.has_text_frame and s.text and s.name.startswith('Mechanism ')]
            for n,sh in actual.items():
                preceding=[g for g in groups if (g.left<ppt.slide_width/2)==(sh.left<ppt.slide_width/2) and g.top<sh.top]
                group=max(preceding,key=lambda s:s.top)
                assert normalize(group.text)==normalize(expected[n]['mechanism_group']), (sh.text,group.text)
    duplicates={}
    for field in ['doi','eprint']:
        groups=defaultdict(list)
        for e in entries:
            v=e.get(field,'').lower().replace('https://doi.org/','').strip('{} ')
            if v:groups[v].append(e['key'])
        duplicates[field]={v:ks for v,ks in groups.items() if len(ks)>1}
    assert not any(duplicates.values()), duplicates
    titles=defaultdict(list)
    for e in entries:titles[normalize(e.get('title',''))].append(e['key'])
    duplicate_titles={t:ks for t,ks in titles.items() if t and len(ks)>1}
    assert not duplicate_titles,duplicate_titles
    with (OUT/'figure_citation_audit.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    (OUT/'figure_citation_audit.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    batchrows=[r for r in rows if r['citation_key'] in {b['key'] for b in batch}]
    assert len(batchrows)==27
    (OUT/'new27_review.json').write_text(json.dumps(batchrows,ensure_ascii=False,indent=2)+'\n')
    # All measurement tables must remain byte-identical to the authorized source.
    base=ROOT.parent/'survey_1030_revised_source.zip'
    tables={}
    if base.exists():
        with zipfile.ZipFile(base) as z:
            for p in (ROOT/'tables').glob('*.tex'):
                rel=str(p.relative_to(ROOT));matches=[n for n in z.namelist() if n==rel or n.endswith('/'+rel)]
                assert len(matches)==1, (rel,matches)
                same=p.read_bytes()==z.read(matches[0]);assert same,rel
                tables[rel]='byte-identical'
    result={'bibliography_unique_keys':len(keys),'active_main_citation_keys':len(used),'unresolved_citation_keys':sorted(used-set(keys)),'duplicate_keys':[],'duplicate_doi_or_eprint':duplicates,'duplicate_normalized_titles':duplicate_titles,'complete_diagram_methods':136,'latest_input_ppt_node_and_group_mapping':'both 136-node slides agree with the citation catalogue','main_timeline_methods':selected['timeline_count'],'main_timeline_route_counts':selected['timeline_route_counts'],'main_taxonomy_mechanism_groups':sum(len(groups) for groups in selected['taxonomy'].values()),'catalogue_mechanism_groups':len({r['mechanism_group'] for r in records}),'all_136_methods_cited_in_main':True,'new_batch_entries':27,'genuinely_new_keys_already_in_1030_source':24,'existing_keys_new_to_figure':3,'new_keys_added_by_this_integration':0,'measurement_tables':tables,'audit_scope':'Prior citation and classification checks retained. Main mechanism chart now shows 14 selected groups; the 136-method timeline retains all entries. EMO and MultiTalk primary texts were revisited for continuation scope; no new blanket speed or long-video claims.'}
    (OUT/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
