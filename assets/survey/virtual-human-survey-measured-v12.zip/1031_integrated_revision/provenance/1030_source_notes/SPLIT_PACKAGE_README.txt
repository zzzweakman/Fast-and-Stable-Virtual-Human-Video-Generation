分包说明 / Split package (2026-10-30)

为满足附件大小限制，完整源码无损拆为两个 ZIP：
1. survey_1030_revised_source.zip：论文编译源码、分类 Bib、更新 BBL、所有正式插图 PDF/PNG、校验与修改说明。无需第二包即可编译论文。
2. survey_1030_figure_authoring.zip：全部 figures/source/ 可编辑图稿、构建脚本、字体、输入素材和研究/日期元数据。

恢复完整目录：将两个 ZIP 解压到同一父目录；两者都使用 survey_1030_revised_source/ 为根目录。第二包的 figures/source/ 会自动合并到论文源码目录。也可把该目录手动复制到论文的 figures/source/。
两个包保留原完整源包的每一个文件，原文件字节不变；仅新增本分包说明。不要把图稿构建目录误当论文编译依赖。

可编辑 PPT 已单独交付（Library file libfile_38cfc7682e208191833450ac71261108，version 2）。本分包不要求再次下载 PPT 才能编译论文；图稿包保留可复现图形工作流所需文件。

Extract both ZIPs into the same parent directory to restore the full source tree. The slim LaTeX ZIP alone contains every manuscript compilation input. All original files are preserved byte-for-byte; only this split-package note is added.
