# 1019 实测更新版

入口：[论文 PDF](main.pdf)（62 页）、[LaTeX 主文件](main.tex)、[更新报告](REVISION_REPORT.md)。

本版在 1016 精简稿基础上整合 2026-10-19 重复测试：55 个方法、56 套配置，每套三次完整预热和三次正式调用。MuseTalk、VideoReTalking 已复测；SoulX 系列和六个附加方法已纳入。

结果表展示正式调用均值、Call 的样本标准差、模型驻留方式，以及正式窗口与整套 suite 显存峰值。所有 336 次调用及完整阶段统计见 [measurements](measurements/README.md)。

## 生成和编译

原始 Excel 与 README 位于 ../material/latency/1019_update。导入使用 openpyxl，重新生成的目录必须不存在：

    python revision/import_measurements.py --source-dir ../material/latency/1019_update --output-dir /tmp/new-h200-import

生成表格仅依赖 Python 标准库和本版 measurements 下的数据：

    python revision/generate_measurement_tables.py --output-dir /tmp/new-survey-tables

常规 TeX 环境：

    python revision/build_pdf.py --project .

本轮 PDF 使用 Tectonic 0.17.0 编译：

    tectonic --keep-logs --keep-intermediates --outdir /tmp/new-survey-pdf main.tex

[实验结果网站](https://zzzweakman.github.io/Fast-and-Stable-Virtual-Human-Video-Generation/measurements.html)提供同一版 CSV、含逐次统计的 JSON 和 336 次调用 CSV。内部机器标识、绝对服务器路径和原始工作簿不进入公开源码包。

