"""Generate manuscript tables from the verified 3+3 measurement records."""
from pathlib import Path
import argparse
import json

PROJECT = Path(__file__).resolve().parents[1]
NAMES = {'Wav2Lip-GAN': 'Wav2Lip+GAN', 'LiveSpeechPortraits': 'Live Speech Portraits',
         'AvatarForcing-SlidingWindow': 'AvatarForcing-SW', 'First-Order-Motion-Model': 'FOMM',
         'TPS-Motion-Model': 'TPS Motion Model', 'TalkLikeYou': 'Talk Like You',
         'LiveAvatar': 'Live Avatar', 'LipForcing': 'Lip Forcing'}
COMMON = r'''Times are means of three measured calls after three complete warm-ups in the same interpreter; Call includes sample standard deviation. $R$: audited model objects or the GPU worker remain resident; other configurations reload models each call. Load is per-call model loading (NR: no recorded interval, not zero); Call spans inference entry to synchronized return, including loading and native extra validation, excluding generic output QA. $M_w$: maximum NVML peak over the three measured windows; $M_s$: whole-suite peak including setup, warm-ups and QA (GiB). NVML samples approximately every 100 ms. $N$: actual output frames; dimensions exclude comparison panels but may exceed the internal synthesis crop. Workloads differ. Full stage statistics, all six calls, phase unions and suite process times accompany the paper.'''
NOTES = {
    'gan': r'''MuseTalk and VideoReTalking now contain completed remeasurements; their first-call peaks are discussed in Section~\ref{sec:eval-common}. Ten configurations retain audited models; MakeItTalk reloads each call. DINet and EAT accept supplied preprocessing products. See Table~\ref{tab:measurement-settings-direct}.''',
    'diffusion': r'''Twenty configurations cover 19 methods; FlashHead Lite and Pro are separate configurations. Wan's three encoded frame counts are retained in order; $528\times944$ neural output is cropped to $528\times935$. Its GPU worker persists across calls. Gen generally excludes VAE decoding; exact operators differ. Additional-source configurations and their missing settings are identified in Table~\ref{tab:measurement-settings-diffusion}. Moore-AnimateAnyone is third-party.''',
    'render': r'''Gen includes controller and renderer where present. Ditto and Talk Like You overlap stages; their unions, rather than column sums, measure the inference-stage wall interval. SyncTalk's native validation is in Call but outside Pre/Gen/Post. StyleAvatar has only two frames and rebuilds FaceVerse state each call; its style generator and ORT sessions remain resident. Supplied assets and internal warm-ups are listed in Table~\ref{tab:measurement-settings-render}.''',
    'motion': r'''UniLS predicts motion in Gen and performs FLAME decoding, rendering, smoothing and export in Post. This is a motion visualization, separate from photorealistic appearance generation; native visual-AR coverage remains zero.''',
}


def tex(value):
    return str(value).replace('&', r'\&').replace('_', r'\_').replace('%', r'\%').replace('#', r'\#')


def number(value):
    if value is None:
        return 'NR'
    if 0 < value < 0.005:
        return '$<0.01$'
    return f'{value:.2f}'


def name(row, cite=True):
    result = tex(NAMES.get(row['method'], row['method']))
    if row['model_mode'] == 'resident_models_or_worker':
        result += r'$^{R}$'
    if cite:
        result += r'~\cite{' + row['cite_key'] + '}'
    return result


def measured_table(route, rows):
    title = {'gan': 'GAN-route', 'diffusion': 'diffusion-route', 'render': 'render-route', 'motion': 'motion-visualization'}[route]
    out = r'''% Generated from measurements/h200_results.json.
\begin{table*}[tbp]
\centering\footnotesize
\setlength{\tabcolsep}{2.5pt}
\renewcommand{\arraystretch}{1.10}
\caption{Single-H200 repeated measurements of ''' + str(len(rows)) + ' ' + title + r''' configurations (19 October 2026). Time in seconds; sampled memory in GiB.}
\label{tab:measured-''' + route + r'''}
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lrrrrrrrrr@{}}
\toprule
Configuration & $N$ & $W\!\times\!H$ & Pre & Gen & Post & Load & Call $\pm s$ & $M_w$ & $M_s$\\
\midrule
'''
    for row in rows:
        frames = str(row['frames']) if row['frames'] is not None else '/'.join(map(str, row['frames_per_repeat']))
        cells = [name(row), frames, f"${row['output_width']}\\!\\times\\!{row['output_height']}$"]
        cells += [number(row[k]) for k in ('pre_s', 'generation_s', 'post_s', 'load_s')]
        cells += [f"${row['call_s']:.2f}\\pm{row['call_sd_s']:.2f}$", number(row['measured_nvml_peak_gib']), number(row['suite_nvml_peak_gib'])]
        out += ' & '.join(cells) + r' \\' + '\n'
    return out + r'''\bottomrule
\end{tabular*}
\par\smallskip
\begin{minipage}{\textwidth}\footnotesize
''' + COMMON + '\n' + r'\par\smallskip' + '\n' + NOTES[route] + r'''
\end{minipage}
\end{table*}
'''


def settings_table(rows, label, title, settings):
    out = r'''\begin{table*}[p]
\centering\small
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.06}
\caption{''' + title + r''' $R$ denotes retained models/worker; all other rows reload each call. Supplied assets remain input prerequisites.}
\label{tab:measurement-settings-''' + label + r'''}
\begin{tabularx}{\textwidth}{@{}L{0.20\textwidth}L{0.30\textwidth}Y@{}}
\toprule
Configuration & Input / configuration & Stage boundary or prerequisite\\
\midrule
'''
    for row in rows:
        conf, boundary = settings[row['method']]
        out += ' & '.join((name(row, False), tex(conf), tex(boundary))) + r' \\' + '\n'
    return out + '\\bottomrule\n\\end{tabularx}\n\\end{table*}\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    rows = json.loads((PROJECT / 'measurements/h200_results.json').read_text())
    settings = json.loads((PROJECT / 'measurements/table_settings.json').read_text())
    for route in ('gan', 'diffusion', 'render', 'motion'):
        selected = [r for r in rows if r['route'] == route]
        (args.output_dir / f'measured_{route}.tex').write_text(measured_table(route, selected))
    for filename, label, routes, title in [
        ('direct', 'direct', ('gan',), 'Input settings and stage boundaries for the 11 GAN configurations.'),
        ('diffusion', 'diffusion', ('diffusion',), 'Input settings and stage boundaries for the 20 diffusion configurations.'),
        ('render', 'render', ('render', 'motion'), 'Settings for the 24 appearance-reuse configurations and the motion visualization.')]:
        selected = [r for r in rows if r['route'] in routes]
        (args.output_dir / f'measurement_settings_{filename}.tex').write_text(settings_table(selected, label, title, settings))
    selected = [r for r in rows if r['method'] in ('MuseTalk', 'VideoReTalking')]
    out = r'''\begin{table}[tbp]
\centering\small
\caption{First-call and measured-window NVML peaks under the same 3+3 protocol (GiB). Whole-suite peaks equal the first-call values for these two configurations.}
\label{tab:warmup-memory}
\begin{tabular}{@{}lrr@{}}
\toprule
Configuration & First warm-up & Measured maximum\\
\midrule
'''
    for row in selected:
        out += tex(row['method']) + f" & {row['first_warmup_nvml_peak_gib']:.2f} & {row['measured_nvml_peak_gib']:.2f}" + r' \\' + '\n'
    out += '\\bottomrule\n\\end{tabular}\n\\end{table}\n'
    (args.output_dir / 'measured_warmup_memory.tex').write_text(out)
    print('Generated eight tables from 56 configurations.')


if __name__ == '__main__':
    main()
