# DBLP 引用核对与修订报告

核对日期：2026-10-13

## 结果与文件入口

本轮以 `1013_literature_enriched` 为基线，另存为 **`1013_dblp_checked`**。上一版 77 个文件的 SHA256 均保持不变。论文仍实际引用 **263 条**文献，网站仍收录 **185 篇**，没有为改变统计数量而添加或删除论文。新版 PDF 为 **58 页**；页数增加主要来自完整作者名单和新增文献链接。

- [论文 PDF](main.pdf) / [LaTeX 入口](main.tex)。
- [逐条核对 CSV](revision/dblp_reference_check.csv)：适合快速筛选。
- [逐字段修改 JSON](revision/dblp_reference_check.json)：包含修改前后值、引用位置范围和 DBLP 永久链接。
- [DBLP 原始字段](revision/dblp_records.json) / [SPARQL 查询](revision/dblp_queries/) / [源码差异](revision/dblp_changes.diff)。
- [可编译源码包](virtual-human-survey-dblp-2026-10-13.zip)。

## 核对范围

| 范围 | 总数 | 匹配 DBLP | 未匹配 |
|---|---:|---:|---:|
| 论文全部 BibTeX 条目 | 274 | 261 | 13 |
| 其中：论文 PDF 实际引用 | 263 | 252 | 11 |
| 网站文献目录 | 185 | 180 | 5 |
| 合并去重后的引用记录 | 284 | 270 | 14 |

这些集合存在重叠，不能相加。网站有 10 个引用 key 不在论文 BibTeX 库中，论文库另有 11 条未在正文使用的文献。本轮覆盖了这些条目，而不只是页面默认展示的文献。匹配后的 270 条对应 270 个不同的 DBLP 记录。

**不能声称全部引用都已获 DBLP 确认。** 剩余 14 条的核对状态和处理方式见后文；它们保留原始来源，未编造 DBLP 链接，也未标记为已经核实。

## 依据与判断方法

1. 通过 [DBLP 官方 SPARQL 服务](https://sparql.dblp.org/) 批量检索题名，读取记录字段和有序作者签名；另外检查 arXiv 编号、更名关系及容易混淆的同名论文。普通网页/API 遇到访问限制时，改用同属 DBLP 的官方数据接口，未用第三方数据库替代 DBLP 作裁决。
2. 身份判断结合标题、作者和来源编号。标题相同不代表同一工作。例如 `Generative Adversarial Networks` 存在不同作者的同名记录，本轮保留 Goodfellow 等人的 CACM 2020 版本。
3. 会议论文优先保留原稿所引会议版本，不自动改成同名后续期刊扩展。例如 ArcFace、StyleGAN、NeRF 保留原会议版本。已确认同一工作的预印本，在 DBLP 有正式会议记录时改用该记录，共 15 条。
4. **年份按 DBLP 引用口径处理。** 会议条目使用 `yearOfEvent`，其余使用 `yearOfPublication`。DBLP 的论文集出版年可能与会议年不同；已用 [Out of Time 的 DBLP BibTeX](https://dblp.org/rec/conf/accv/ChungZ16a.html?view=bibtex) 和 [官方字段说明](https://dblp.org/rdf/docu/)交叉确认。因此 EDTalk 等仍写 ECCV 2024，Out of Time 仍写 ACCV Workshops 2016，没有误改为论文集出版年。
5. 作者按 DBLP 顺序完整写入，去掉只用于消歧的姓名尾部四位编号；原始编号与作者 PID 保存在 JSON 中。团体署名保留为团体作者。会议和期刊采用 DBLP 简称，页码包含 DBLP 的文章编号格式。
6. DBLP 没有给出的页码、DOI 等不自行补造。删除旧值只表示当前引用遵循 DBLP 字段集合，不等于已经证实旧值错误。文献 key 保持不变，避免破坏正文、预览图和外部链接。

## 具体改了什么

### 标题、更名与作者

5 条标题发生实质文字调整，另统一了大小写保护和标点格式：

| 原条目 | DBLP 采用的标题 | 处理理由 |
|---|---|---|
| FluentAvatar: Flicker-Free Talking-Head Animation via Phoneme-Guided Autoregressive Modeling | [AvatarSync: Rethinking Talking-Head Animation through Autoregressive Perspective](https://dblp.org/rec/journals/corr/abs-2509-12052) | 同一 arXiv:2509.12052。书目改为 AvatarSync；网站仍保留 FluentAvatar 的 v3 技术说明和检索名。 |
| MuseTalk: Real-time high-fidelity video dubbing via spatio-temporal sampling | [MuseTalk: Real-Time High Quality Lip Synchronization with Latent Space Inpainting](https://dblp.org/rec/journals/corr/abs-2410-10122) | 同一 arXiv:2410.10122。书目标题及作者顺序按 DBLP；在网站注明与所讨论后续版本的标题差异。 |
| JoyStreamer-Flash: Real-time and Infinite Audio-Driven Avatar Generation with Autoregressive Diffusion | [JoyAvatar: Real-time and Infinite Audio-Driven Avatar Generation with Autoregressive Diffusion](https://dblp.org/rec/journals/corr/abs-2512-11423) | 同一 arXiv:2512.11423。引用采用 JoyAvatar；正文首次出现时说明 JoyStreamer-Flash 是其第三版。保留 v3 原文链接及版本专属测量。 |
| Advancements in talking head generation: a comprehensive review of techniques, metrics, and challenges: Advancements in talking head generation... | [Advancements in talking head generation: a comprehensive review of techniques, metrics, and challenges](https://dblp.org/rec/journals/vc/RakeshMMPDS26) | 去掉重复拼接的副标题，采用 DBLP 完整题名。 |
| AVTR-1 | [AVTR-1: Open Stack for Real-Time Interactive Avatars](https://dblp.org/rec/journals/corr/abs-2609-22913) | 原先只引用 AVTR-1 项目名和首页；改为 DBLP 收录的对应论文，补全标题并按论文作者排序。 |

作者字段共调整 60 条，包括补齐被 `and others` 截断的名单、名字拼写与中间名，以及不同版本的作者顺序，不能把这 60 条全部称为“原稿错误”。例如：

- Self-Forcing++ 按 DBLP 使用 Jiaxing Cui。
- AVTR-1 的论文作者顺序以 Artem Kravtsov 开头；不再沿用原项目条目中的名单。
- Qwen3 / Qwen3-VL 库内条目按 DBLP 采用 Qwen Team 团体署名。
- Wan 按 DBLP 采用论文作者列表，不额外将原条目的 “Wan Team” 并列为第一作者。
- MuseTalk 的作者列表随 DBLP 所收录版本一起对齐；网站明确说明后续版本名称，避免把版本差异直接说成原文署名错误。

JoyAvatar 更名关系仅限 arXiv:2512.11423；没有与 arXiv:2602.00702 的另一篇 JoyAvatar 合并。AvatarSync/FluentAvatar 仍是原来的相关背景条目，未据书目更名改变其视觉 AR 分类。

### 年份与引用版本

17 个书目条目的引用年份发生变化。包含从预印本转为正式会议、期刊卷期年份对齐，以及从再版条目回溯原始论文；这些不是同一种错误。

| 文献 | 原年份 | DBLP 引用年份 | 采用出处 |
|---|---:|---:|---|
| [AvatarSync](https://dblp.org/rec/journals/corr/abs-2509-12052) | 2026 | 2025 | CoRR |
| [SpeakerVid-5M](https://dblp.org/rec/conf/iclr/ZhangLWZZYDYL26) | 2025 | 2026 | ICLR |
| [SoulX-FlashTalk](https://dblp.org/rec/journals/corr/abs-2512-23379) | 2026 | 2025 | CoRR |
| [OmniTalker](https://dblp.org/rec/conf/nips/WangZQWXZ25) | 2026 | 2025 | NeurIPS |
| [RAP](https://dblp.org/rec/journals/corr/abs-2508-05115) | 2026 | 2025 | CoRR |
| [MotionStream](https://dblp.org/rec/conf/iclr/ShinLZZPSH26) | 2025 | 2026 | ICLR |
| [Rolling Forcing](https://dblp.org/rec/conf/iclr/LiuHXSL26) | 2025 | 2026 | ICLR |
| [Advancements in talking head generation](https://dblp.org/rec/journals/vc/RakeshMMPDS26) | 2025 | 2026 | Vis. Comput. |
| [LTX-Video](https://dblp.org/rec/journals/corr/abs-2501-00103) | 2024 | 2025 | CoRR |
| [Auto-Encoding Variational Bayes](https://dblp.org/rec/journals/corr/KingmaW13) | 2013 | 2014 | ICLR |
| [Self-Forcing++](https://dblp.org/rec/conf/iclr/CuiWLYLWBBH26) | 2025 | 2026 | ICLR |
| [Self Forcing](https://dblp.org/rec/conf/nips/HuangLHZS25) | 2026 | 2025 | NeurIPS |
| [LongLive](https://dblp.org/rec/conf/iclr/YangHCXZWLXCLHC26) | 2025 | 2026 | ICLR |
| [A Morphable Model for the Synthesis of 3D Faces](https://dblp.org/rec/conf/siggraph/BlanzV99) | 2023 | 1999 | SIGGRAPH |
| [OpenPose](https://dblp.org/rec/journals/pami/CaoHSWS21) | 2019 | 2021 | IEEE Trans. Pattern Anal. Mach. Intell. |
| [VASA-3D](https://dblp.org/rec/conf/nips/XuCYZDLG25) | 2026 | 2025 | NeurIPS |
| [GaussianHand](https://dblp.org/rec/journals/tvcg/ZhaoLFIW25) | 2024 | 2025 | IEEE Trans. Vis. Comput. Graph. |

Blanz–Vetter 的 3D morphable model 原条目是 2023 年再版书章。本轮选用 DBLP 可确认的 SIGGRAPH 1999 原始论文，页码随之改为 187–194；这不表示该工作到 2023 年才首次出现，也不把再版本身判为不存在。原 citation key `blanz2023morphable` 保留。

### 页码、类型与标识符

- 78 条页码字段发生补充、规范化、更正或移除。其中 ACM 文章采用 `55:1–55:9` 一类完整文章编号，不再统一写成 `1–9`。
- 如 Latent Diffusion 在本稿采用的 CVPR 2022 条目，页码由 10684–10695 对齐为 DBLP 的 10674–10685；MMVID 的 CVPR 2022 页码对齐为 3605–3615。逐条来源链接见 JSON。
- 199 条补入 DBLP 提供的 DOI；其他 DOI 字段变化包括大小写统一及转用正式会议版本后省去原预印本 DOI。
- 将一些写成 `article` 的会议论文改为 `inproceedings`，CoRR 条目补齐 `abs/...` 卷号，会议名和期刊名采用 DBLP 简称。
- 每条匹配记录加入 DBLP 书目出处字段，便于追溯。源论文链接和 DBLP 记录链接分别说明其用途。
- 新增长 URL 后启用 `xurl`，解决双栏参考文献中的长哈希链接超宽问题；未改变文献样式文件。

## 未匹配的 14 条与后续关注点

“未匹配”表示截至本次检查，使用官方检索及相应题名、作者或编号线索没有确认到对应记录；不等同于断言 DBLP 永远不会收录，也不等同于论文不存在。标准与技术报告不因缺少 DBLP 记录而自动删除。

| 引用 key / 文献 | 使用范围 | 当前处理与限制 |
|---|---|---|
| `xiong2026voxface`<br>VoxFace: Streaming Audio-Visual Synthesis via Relay-Style Multi-Token Prediction for Interactive Conversation | 论文库未引用 | 题名、作者线索与缩写检索未找到对应 DBLP 记录；未在正文或网站使用，保留为未确认的库内条目。 |
| `chandra2024synthetic`<br>[Reducing Risks Posed by Synthetic Content: An Overview of Technical Approaches to Digital Content Transparency](https://doi.org/10.6028/NIST.AI.100-4) | 论文正文 | NIST 技术报告；保留原 DOI，不以检索未匹配推断文献不存在。 |
| `c2pa2026technical`<br>[C2PA Technical Specification](https://spec.c2pa.org/specifications/specifications/2.4/specs/C2PA_Specification.html) | 论文正文 | C2PA 标准文档；保留官方规范链接和版本号。 |
| `c2pa2026security`<br>[C2PA Security Considerations](https://spec.c2pa.org/specifications/specifications/2.4/security/Security_Considerations.html) | 论文正文 | C2PA 安全说明；保留官方文档链接和版本号。 |
| `c2pa2026harms`<br>[C2PA Harms Modelling](https://spec.c2pa.org/specifications/specifications/2.4/security/Harms_Modelling.html) | 论文正文 | C2PA 风险建模说明；保留官方文档链接和版本号。 |
| `zabaletainteractive`<br>Interactive Real-Time Visual Avatar Generation: A Survey | 论文正文 | 原记录标为未发表手稿，未找到 DBLP 对应项；缺少可据 DBLP 核定的正式出版信息，建议作者优先复核其公开出处。 |
| `nvidia2024ace`<br>[NVIDIA ACE: Autonomous Game Characters with Generative AI](https://developer.nvidia.com/ace) | 论文库未引用 | 厂商文档；正文和网站均未引用此条目。 |
| `huang2026flowactr2`<br>[FlowAct-R2: Beyond Talking Avatar via Streaming Multimodal References and Proactive Agent Planning](https://arxiv.org/abs/2609.35728v1) | 论文正文；网站 | 近期预印本，完整题名、缩写与 arXiv 编号均未匹配；保留此前采用的原文版本。 |
| `su2026routedforcing`<br>[Where and When to Force: Routed Forcing for Streaming Avatars](https://arxiv.org/abs/2609.30963v1) | 论文正文；网站 | 近期预印本，题名、缩写与 arXiv 编号均未匹配；保留此前采用的原文版本。 |
| `tang2026rgor`<br>[Beyond Lip Sync: Reference-Grounded Oral Refinement for Audio-Driven Portrait Animation](https://arxiv.org/abs/2609.38019v1) | 论文正文；网站 | 近期预印本，题名与 arXiv 编号未匹配；DBLP 中其他 RGOR 论文不是同一工作，未替换。 |
| `wang2026talklikeyou`<br>[Talk Like You: Imitating How You Speak in Real-Time Talking Head Generation](https://arxiv.org/abs/2610.06658v1) | 论文正文；网站 | 近期预印本，题名与 arXiv 编号均未匹配；保留此前采用的原文版本。 |
| `radford2018improving`<br>Improving language understanding by generative pre-training | 论文正文 | OpenAI 技术报告，未匹配 DBLP。原条目的作者尾项和出版者字段未能据 DBLP 复核，仍需单独确认。 |
| `ekman1978facial`<br>Facial Action Coding System | 论文正文 | 较早的 FACS 文献，未匹配 DBLP。当前库将其写为期刊文章；文献类型及出版信息列为人工复核重点，本轮未凭推测修改。 |
| `habib2026pixreenact`<br>[PixReenact: Pixel-Conditioned Causal Video Diffusion for Streaming Head-Avatar Reenactment](https://arxiv.org/abs/2610.05233) | 网站 | 仅网站收录的近期预印本，题名与 arXiv 编号均未匹配；保留原始引用。 |

需要优先人工确认的是未发表 survey 的公开出处、FACS 的文献类型，以及 GPT-1 技术报告的完整出版字段。它们目前仍是未完成 DBLP 确认的条目，报告不为这些信息背书。近期预印本可以在 DBLP 后续更新后补查。

## 网站同步与统计

- 180 条匹配记录的标题、作者、年份、出处和复制/下载 BibTeX，与论文中对应记录使用同一组规范字段。网站额外文献也独立核对。
- 引用面板显示 DBLP 来源；5 条未匹配的近期预印本保留原始引用并明确提示未找到对应记录。
- JoyAvatar/JoyStreamer-Flash 与 AvatarSync/FluentAvatar 都可检索；稳定的网页 ID、图片、原始来源链接及交叉索引不变。
- 年度图继续只显示总量，不恢复分类条形图或 Generation route 数量。校正后的 2024 / 2025 / 2026 年数量分别为 **28 / 50 / 62**，所有年份合计仍为 **185**。
- 同步新版 PDF、源码 ZIP、完整 185 条目录 BibTeX、英文说明和独立发布清单；以前的 PDF、源码包和冻结数据均保留。
- 浏览器检查发现导出按钮的 BIB 标签在悬停状态下对比度不足，去掉该标签的半透明度；界面结构保持原样。

## 统一实测与技术内容

统一实测模板仍为 **0 条数据**。一次生成的帧数、分辨率、预处理/生成/后处理耗时和峰值显存，等待作者在统一环境中提供结果后再填写。本轮未把 DBLP 的出版信息用作性能结论，也未改动已有测量数字。

正文仅补充 JoyAvatar 与 JoyStreamer-Flash 的版本关系；其余修改集中在书目和必要的 URL 排版。网站 185 条的技术摘要、分类、原文链接、机制记录和测量关联均通过前后对比确认未变。时间线图仍按图注所说明的首次公开版本组织，不把它与引用年份混为一谈。

## 验证结果

- 四轮 LaTeX 和 BibTeX 编译通过；263 条实际引用，0 个未定义引用、0 条 LaTeX/BibTeX 警告、0 个 overfull box。
- 对全部 270 条匹配记录再次逐字段检查标题、作者顺序、类型、年份、页码和 DOI；无重复 DBLP 身份。
- 论文与网站共有条目的导出 BibTeX 一致；独立网站文献也使用同样的规范化规则。
- 新版 PDF 的修改段落和代表性参考文献页已检查；无 Type 3 字体。
- 网站 16 项目录行为测试与 3 项资源版本构建测试通过。
- 桌面和 390 / 320 像素移动端的引用展示、别名检索、年度统计和下载已检查；详细结果见 `revision/website_validation.json`。
- 上一版 77 个文件保持原样；各个网站历史发布清单继续通过 SHA256 校验。

## 写作自查

| 检查点 | 结论 |
|---|---|
| 是否把格式补全夸大为事实纠错？ | 已区分标题/年份问题、版本更新、作者补全及格式规范。 |
| 是否混淆同名论文或不同版本？ | 按作者与来源编号确认；保留技术描述所用版本，明确三个主要更名关系。 |
| 是否无依据宣称全部正确？ | 没有。14 条明确列为未匹配，原信息仍有待复核。 |
| 是否因引用更新更改性能结论？ | 没有。原测量条件保留，统一实测仍待完成。 |
| 结果能否逐项复查？ | 提供 DBLP 永久链接、原始字段、修改前后记录、CSV 与源码差异。 |

GitHub 发布后的提交号和部署检查记录单独写入 `revision/github_deployment.json`，不改写已冻结的源码发布包。
