# DBLP 引用核对版综述

日期：2026-10-13。最新论文在此目录；上一版保留在 `../1013_literature_enriched`。

- [main.pdf](main.pdf)：58 页阅读稿，263 条实际引用。
- [main.tex](main.tex)：LaTeX 入口；`sec_new/`、`bib/`、`figures/` 为完整源码。
- [REVISION_REPORT.md](REVISION_REPORT.md)：修订内容、理由、匹配范围及 14 条未匹配文献。
- [逐条核对表](revision/dblp_reference_check.csv) / [完整修改字段](revision/dblp_reference_check.json)。
- `measurements/`：统一实测约定与空模板，等待作者提供数值。

合并核对 284 条引用记录，270 条匹配 DBLP；其中论文实际引用匹配 252/263，网站匹配 180/185。未匹配条目保持原始来源，不能视为已完成 DBLP 确认。

在正常 TeX Live 环境运行 `python3 revision/build_pdf.py`；脚本使用新临时目录编译，不覆盖源文件或已有 PDF。源码包也可导入 Overleaf，以 `main.tex` 为入口。
