# 新配图同步与实测表说明精简

当前交付：[论文 PDF](main.pdf)（55 页）、[LaTeX 主文件](main.tex)。

## 修改提纲与段落职责

- 配图与图注：逐张检查用户裁切、删字后的十张矢量图，保留新版画面；精简图注，保留面板定义和图片来源。
- 阶段占比图：删除图注中的旧内嵌数值表描述，说明阶段均值 / Call 均值及 Other 的定义。绝对耗时和输出规模在正文引用 GAN、render 实测表。
- 实测表：四张表底部的长说明全部移除，caption 只保留三次预热 / 三次测量、秒单位、必要符号和协议引用。
- 共享协议：统一解释帧数与输出尺寸、模型驻留、计时边界和 warmed memory；各路线正文保留预处理资产、VAE 解码、阶段重叠和运动可视化等特定说明。
- 排版：允许两张跨栏浮动体共同位于页顶，让较短实测表与正文合页。字体大小不变；15 张年份表、四张完整 Takeaways 卡片、双栏附录保留，附录前两张配置表共页。

SoulX-FlashTalk 在用户新版分类图和时间轴中再次标为 2026；已统一为现有参考文献的 2025，时间轴条目移回对应列，其余裁切与删字保留。原用户版本的校验值记录在 [图稿记录](revision/figure_update.json)。

## 图表位置

| 对象 | 页 |
|---|---|
| Figure 1 (`fig:visual-scope`) | 2 |
| Figure 2 (`fig:fast-stable`) | 2 |
| Figure 3 (`fig:timeline`) | 3 |
| Figure 4 (`fig:taxonomy`) | 5 |
| Figure 5 (`fig:system-boundary`) | 6 |
| Figure 6 (`fig:hybrid-decisions`) | 8 |
| Figure 7 (`fig:drift-control-patterns`) | 11 |
| Figure 8 (`fig:diffusion-fast-long`) | 16 |
| Figure 9 (`fig:render-interface-decomposition`) | 26 |
| Figure 10 (`fig:measured-stage-cost`) | 38 |
| Table 5 (`tab:measured-gan`) | 14 |
| Table 7 (`tab:measured-diffusion`) | 19 |
| Table 10 (`tab:measured-motion`) | 24 |
| Table 12 (`tab:measured-render`) | 30 |

Takeaways 位于第 13, 21, 25, 30 页；附录文字从第 41 页开始，配置表位于第 42, 43 页，参考文献从第 44 页开始。

## 主张与证据

| 主张 | 证据 | 状态 |
|---|---|---|
| 图文与删减后的画面一致 | 十图逐张检查，Figure 10 仅描述占比条形图，绝对值改引正文表格 | 已支持 |
| 精简说明不丢失读表条件 | 各表 caption 定义 N、s 及实际出现的 R/NR；共用协议和对应正文保留关键边界 | 已支持 |
| 原始实测数据保留 | 56 行表格数值逐行匹配上一版；原始数据、bib 与三张配置表逐字节一致；266 个引用键保留 | 已支持 |
| 阶段占比仍对应原测量 | 三条矢量条形的各段宽度与阶段均值 / Call 均值核对，最大偏差小于 0.05 个百分点 | 已支持 |

## 五维自审

| 维度 | 问题与结论 |
|---|---|
| 贡献 | 是否扩大结论？没有，仍分析各配置的阶段成本。 |
| 清晰度 | 是否还引用已删除的图内表格？没有；各段分别承担协议、结果解释或限制说明。 |
| 实验证据 | 是否改动测量数值？没有，全部实测结果与记录保留。 |
| 评估完整性 | 是否暗示统一排名、TTFF 或连续稳定性验证？没有，原有证据边界保留。 |
| 设置合理性 | 表注精简后是否缺少符号或阶段定义？没有，短 caption 与实验协议互相衔接；附录仍为双栏。 |

编译：未定义引用 0，overfull box 0，页界外文字 0。详见 [PDF 验证](revision/pdf_validation.json) 和 [排版记录](revision/style_layout_validation.json)。
