"""Generate manuscript tables from the verified 3+3 measurement records."""
from pathlib import Path
import argparse
import json
import re
from functools import lru_cache

PROJECT = Path(__file__).resolve().parents[1]
NAMES = {'Wav2Lip-GAN': 'Wav2Lip+GAN', 'LiveSpeechPortraits': 'Live Speech Portraits',
         'AvatarForcing-SlidingWindow': 'AvatarForcing-SW', 'First-Order-Motion-Model': 'FOMM',
         'TPS-Motion-Model': 'TPS Motion Model', 'TalkLikeYou': 'Talk Like You',
         'LiveAvatar': 'Live Avatar', 'LipForcing': 'Lip Forcing'}


def tex(value):
    return str(value).replace('&', r'\&').replace('_', r'\_').replace('%', r'\%').replace('#', r'\#')


def number(value):
    if value is None:
        return 'NR'
    if 0 < value < 0.005:
        return '$<0.01$'
    return f'{value:.2f}'


def name(row, cite=True):
    result = tex(NAMES.get(row['method'], row['method']))
    if row['model_mode'] == 'resident_models_or_worker':
        result += r'$^{R}$'
    if cite:
        result += r'~\cite{' + row['cite_key'] + '}'
    return result


@lru_cache(maxsize=1)
def publication_years():
    """Use the year of the cited publication, including preprints."""
    years = {}
    for path in sorted((PROJECT / 'bib').glob('*.bib')):
        for entry in re.split(r'(?m)^@', path.read_text())[1:]:
            key = re.match(r'\w+\s*\{\s*([^,]+)', entry)
            year = re.search(r'\byear\s*=\s*[{\"]?(\d{4})', entry, re.I)
            if key and year:
                key, year = key[1].strip(), year[1]
                if key in years and years[key] != year:
                    raise ValueError(f'Conflicting publication years for {key}')
                years[key] = year
    return years


def measured_table(route, rows):
    title = {'gan': 'GAN-route', 'diffusion': 'diffusion-route', 'render': 'render-route', 'motion': 'motion-visualization'}[route]
    legend = r'$N$: output frames; $s$: sample standard deviation.'
    if any(row['model_mode'] == 'resident_models_or_worker' for row in rows):
        legend += r' $R$: resident models/worker.'
    if any(row['load_s'] is None for row in rows):
        legend += r' NR: loading interval not recorded.'
    out = r'''% Generated from measurements/h200_results.json.
\begin{table*}[tbp]
\centering\footnotesize
\setlength{\tabcolsep}{2.5pt}
\renewcommand{\arraystretch}{1.10}
\caption{Our single-H200 measurements of ''' + str(len(rows)) + ' ' + title + (' configuration' if len(rows) == 1 else ' configurations') + r'''. Times are means of three calls after three complete warm-ups, in seconds. ''' + legend + r''' Workloads, stage boundaries and warmed memory $M_w$: Section~\ref{sec:eval-common}.}
\label{tab:measured-''' + route + r'''}
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}lcrrrrrrrr@{}}
\toprule
Configuration & Year & $N$ & $W\!\times\!H$ & Pre & Gen & Post & Load & Call $\pm s$ & \shortstack{Warm peak\\$M_w$ (GiB)}\\
\midrule
'''
    for row in rows:
        frames = str(row['frames']) if row['frames'] is not None else '/'.join(map(str, row['frames_per_repeat']))
        cells = [name(row), publication_years()[row['cite_key']], frames,
                 f"${row['output_width']}\\!\\times\\!{row['output_height']}$"]
        cells += [number(row[k]) for k in ('pre_s', 'generation_s', 'post_s', 'load_s')]
        cells += [f"${row['call_s']:.2f}\\pm{row['call_sd_s']:.2f}$", number(row['measured_nvml_peak_gib'])]
        out += ' & '.join(cells) + r' \\' + '\n'
    return out + r'''\bottomrule
\end{tabular*}
\end{table*}
'''


def settings_table(rows, label, title, settings):
    out = r'''\begin{table*}[htbp]
\centering\small
\setlength{\tabcolsep}{2.5pt}
\renewcommand{\arraystretch}{1.0}
\caption{''' + title + r'''}
\label{tab:measurement-settings-''' + label + r'''}
\begin{tabularx}{\textwidth}{@{}L{0.16\textwidth}cY@{}}
\toprule
Configuration & Year & Input / configuration and stage boundary\\
\midrule
'''
    for row in rows:
        conf, boundary = settings[row['method']]
        details = r'\textit{' + tex(conf) + r'}\enspace ' + tex(boundary)
        out += ' & '.join((name(row, False), publication_years()[row['cite_key']], details)) + r' \\' + '\n'
    return out + '\\bottomrule\n\\end{tabularx}\n\\end{table*}\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    rows = json.loads((PROJECT / 'measurements/h200_results.json').read_text())
    settings = json.loads((PROJECT / 'measurements/table_settings.json').read_text())
    for route in ('gan', 'diffusion', 'render', 'motion'):
        selected = [r for r in rows if r['route'] == route]
        (args.output_dir / f'measured_{route}.tex').write_text(measured_table(route, selected))
    for filename, label, routes, title in [
        ('direct', 'direct', ('gan',), 'Input settings and stage boundaries for the 11 GAN configurations.'),
        ('diffusion', 'diffusion', ('diffusion',), 'Input settings and stage boundaries for the 20 diffusion configurations.'),
        ('render', 'render', ('render', 'motion'), 'Settings for the 24 appearance-reuse configurations and the motion visualization.')]:
        selected = [r for r in rows if r['route'] in routes]
        (args.output_dir / f'measurement_settings_{filename}.tex').write_text(settings_table(selected, label, title, settings))
    print('Generated seven tables from 56 configurations.')


if __name__ == '__main__':
    main()
