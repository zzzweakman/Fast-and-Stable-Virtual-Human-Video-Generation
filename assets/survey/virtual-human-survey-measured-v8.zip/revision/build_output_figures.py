"""Rebuild the seven figures with measured output crops and vector layouts.

Run from any directory: python revision/build_output_figures.py
Requires Pillow and PyMuPDF. The packaged frames retain their decoded pixels;
only proportional placement is performed here. Source records are in
revision/output_figure_provenance.json. Templates retain the author's layout.
"""
from pathlib import Path
import pymupdf as pdf
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'figures/measured'
LAYOUTS = ROOT / 'figures/layouts'
OUT = ROOT / 'figures/redesigned'
INK = (0.14, 0.22, 0.28)
MUTED = (0.36, 0.44, 0.51)
GREEN = (0.12, 0.56, 0.48)
BLUE = (0.20, 0.46, 0.73)


def image(page, rect, name):
    page.insert_image(pdf.Rect(rect), filename=str(ASSETS / name), keep_proportion=True)


def strip(page, rect, names, gap=5):
    """Center uncropped frames at equal height within the allotted slot."""
    r = pdf.Rect(rect)
    ratios = []
    for name in names:
        with Image.open(ASSETS / name) as im:
            ratios.append(im.width / im.height)
    height = min(r.height, (r.width - gap * (len(names) - 1)) / sum(ratios))
    width = height * sum(ratios) + gap * (len(names) - 1)
    x, y = r.x0 + (r.width - width) / 2, r.y0 + (r.height - height) / 2
    for name, ratio in zip(names, ratios):
        w = height * ratio
        image(page, (x, y, x + w, y + height), name)
        x += w + gap


def field_schematic(page):
    # Two queried volumes and rays: a representation schematic, not a model dump.
    for y, height in [(198, 38), (240, 24)]:
        page.draw_rect(pdf.Rect(282, y, 338, y + height), color=GREEN, fill=(0.90, 0.96, 0.94), width=.8)
        for offset in [5, 18, 31]:
            page.draw_line((260, 231), (338, y + min(offset, height - 2)), color=(.53,.68,.64), width=.5)
    page.draw_circle((260, 231), 3, color=GREEN, fill=GREEN)


def gaussian_schematic(page):
    # Explicitly schematic Gaussian primitives, never a reconstructed asset.
    for row in range(5):
        for col in range(4):
            x = 278 + col * 17 + (row % 2) * 4
            y = 337 + row * 15
            page.draw_oval(pdf.Rect(x, y, x + 22, y + 11), color=GREEN,
                           fill=(.83 + .015 * row, .92, .88 + .01 * col), width=.55)


def build(name, render):
    doc = pdf.open(LAYOUTS / name)
    render(doc[0])
    doc.save(OUT / name, garbage=4, deflate=True)
    doc.close()


def visual_scope(p):
    strip(p, (12,80,552,207), [f'videoretalking_{n:03}.png' for n in [0,73,146]])
    strip(p, (12,254,552,381), [f'soulx_flashtalk_{n:03}.png' for n in [0,62,125,187,249]])
    strip(p, (12,437,552,559), [f'liveportrait_face_{n:03}.png' for n in [0,39,77]])
    strip(p, (594,80,1130,207), [f'everanimate_{n:03}.png' for n in [0,38,76]])
    # MIDAS remains a clearly attributed literature example in the layout.
    strip(p, (594,437,1130,559), [f'lam_{n:03}.png' for n in [0,25,50]])


def fast_stable(p):
    # Reuse the authored frame positions; the arrival schedule is schematic.
    for rect, name in FRAME_SLOTS['04_fast_stable.pdf']:
        image(p, rect, name)


def system_boundary(p):
    image(p, (38.24,44.95,153.65,160.58), 'liveportrait_reference.png')
    image(p, (1009.58,92.95,1148.35,231.71), 'liveportrait_face_039.png')
    strip(p, (38,218,267,283), [f'liveportrait_driver_{n:03}.png' for n in [0,39,77]], gap=4)


def hybrid_ownership(p):
    image(p, (26.42,460.51,107.58,541.02), 'liveportrait_reference.png')
    image(p, (991,459.42,1071.95,540.58), 'liveportrait_face_039.png')
    for off in [12,6,0]:
        p.draw_rect(pdf.Rect(964+off,265-off,1028+off,311-off), color=BLUE,
                    fill=(.96,.98,1), width=.8)
    p.insert_text((970,334),'RGB frames',fontsize=12,fontname='helv',color=BLUE)


def stability_operations(p):
    for rect, name in FRAME_SLOTS['07_stability_operations.pdf']:
        image(p, rect, name)


def diffusion_execution(p):
    image(p, (24.58,56.82,132.58,164.82), 'follow_emoji_reference.png')
    image(p, (1018.18,64.24,1117.24,163.29), 'follow_emoji_008.png')


def rendering_interfaces(p):
    image(p, (260.75,48,366.78,138.76), 'styleavatar_uv.png')
    image(p, (971.58,62.18,1076.53,149.24), 'styleavatar_000.png')
    field_schematic(p)
    image(p, (972.67,193.53,1075.44,298.47), 'adnerf_008.png')
    gaussian_schematic(p)
    image(p, (971.58,333.82,1076.53,438.76), 'lam_025.png')
    image(p, (220.82,480.22,291.29,550.25), 'liveportrait_reference.png')
    image(p, (971.58,474.33,1076.53,578.84), 'liveportrait_face_039.png')


if __name__ == '__main__':
    import json
    FRAME_SLOTS = json.loads((LAYOUTS / 'frame_slots.json').read_text())
    for name, render in [
        ('03_visual_scope.pdf', visual_scope), ('04_fast_stable.pdf', fast_stable),
        ('05_system_boundary.pdf', system_boundary), ('06_hybrid_ownership.pdf', hybrid_ownership),
        ('07_stability_operations.pdf', stability_operations), ('08_diffusion_execution.pdf', diffusion_execution),
        ('09_rendering_interfaces.pdf', rendering_interfaces),
    ]:
        build(name, render)
    print('Rebuilt seven vector figures from packaged layouts and measured frames.')
