# 实测修订版

入口：[论文 PDF](main.pdf)（55 页）、[LaTeX 主文件](main.tex)、[更新报告](REVISION_REPORT.md)、[语言与排版修订](STYLE_LAYOUT_REPORT.md)。

当前稿参考 MOT 综述的定义—分组—比较写法精简正文。15 张比较、实测与配置表保留文献年份，四条技术路线的设计取舍采用 Takeaways 卡片。七张配图使用正式测量输出、参考与驱动帧，以及实际 UV 中间资产，沿用作者裁切后的矢量布局。MIDAS 保留为注明来源的文献示例；流程、时间轴和场表示示意与实际画面明确区分。实测阶段图仅展示占比，绝对耗时见正文实测表。测速表采用简短 caption，附录与正文统一为双栏文本，宽表跨栏。

实测覆盖 55 个方法、56 套配置，每套三次完整预热和三次正式调用。四张主结果表展示正式调用均值、Call 的样本标准差、模型驻留方式及预热后的显存峰值。完整的 336 次调用及阶段统计见 [measurements](measurements/README.md)。论文具体日历日期已删除，参考文献出版年份保留。

新增结果归档与原记录核对：336 次调用时间一致，56 个配置首轮正式视频的解码帧数和画布尺寸一致。[图像与配置来源记录](revision/output_figure_provenance.json)保存所用帧号、裁切区域、归档相对路径、哈希和六个追加配置的启动记录依据。没有重新运行 GPU 推理或新增质量、长期稳定性结论。

## 生成和编译

原始 Excel 与 README 位于 ../material/latency/1019_update。导入使用 openpyxl，重新生成的目录必须不存在：

    python revision/import_measurements.py --source-dir ../material/latency/1019_update --output-dir /tmp/new-h200-import

生成表格仅依赖 Python 标准库、本版 measurements 下的数据和 bib 中的出版年份：

    python revision/generate_measurement_tables.py --output-dir /tmp/new-survey-tables

重建七张实测配图（需 PyMuPDF 与 Pillow）：

    python revision/build_output_figures.py

源帧位于 `figures/measured`，不含美化或补帧；矢量布局位于 `figures/layouts`，生成图位于 `figures/redesigned`。

常规 TeX 环境：

    python revision/build_pdf.py --project .

本轮 PDF 使用 Tectonic 0.17.0 编译：

    tectonic --keep-logs --keep-intermediates --outdir /tmp/new-survey-pdf main.tex

[实验结果网站](https://zzzweakman.github.io/Fast-and-Stable-Virtual-Human-Video-Generation/measurements.html)提供同一版 CSV、含逐次统计的 JSON 和 336 次调用 CSV。内部机器标识、绝对服务器路径和原始工作簿不进入公开源码包。

