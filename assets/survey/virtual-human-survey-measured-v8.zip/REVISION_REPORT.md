# 当前实测修订报告

当前稿覆盖 55 个方法、56 套配置和 336 次调用，PDF 为 55 页。七张图已使用正式测量的实际素材，图注和相关正文同步修订。

- 任务示例使用 VideoReTalking、SoulX-FlashTalk、LivePortrait、EverAnimate、LAM 的输出；MIDAS 是明确注明的文献示例。
- Fast/Stable、系统边界、混合架构和稳定性操作使用 LivePortrait 的参考、驱动与生成画面；到达时序和结构关系仍是示意。
- 扩散流程使用 Follow-Your-Emoji-Faster 的参考及输出；FADA 调用次数继续来自文献，不作为本地运行结果。
- 渲染接口使用 StyleAvatar 的真实 UV 与 RGB，以及 AD-NeRF、LAM 和 LivePortrait 的输出；场表示、Gaussian primitives 和特征栈明确标为示意。
- 归档中的 JSON、336 轮记录、阶段事件、NVML 样本及视频补充了原工作簿。全部调用时间匹配原记录，56 个首轮主输出已解码核对。新增启动记录补充六个配置的附录说明。

33 个图像资产、七个矢量布局和重建脚本随源码交付。来源见 [图像与配置记录](revision/output_figure_provenance.json)。素材保留解码后的像素，按原比例放置；比较视频仅提取有记录的参考、驱动或生成区域，不进行美化、补帧或生成式重绘。

四张主结果表和原始数值导出均未改变。Call、Suite、预热后显存峰值和阶段边界的含义保留；15 张年份表、四张 Takeaways 卡片、简短测速表注和双栏附录保留。

本次没有新增 GPU 推理。短片示例不构成统一质量排名或长时稳定性评估。归档不包含适配器源码、权重和完整环境；Wan 的原始 pre-mux 文件已被覆盖，相关说明来自归档审查及编码日志。

版式和写作审查见 [语言与排版报告](STYLE_LAYOUT_REPORT.md)，编译检查见 [PDF 验证](revision/pdf_validation.json)。
