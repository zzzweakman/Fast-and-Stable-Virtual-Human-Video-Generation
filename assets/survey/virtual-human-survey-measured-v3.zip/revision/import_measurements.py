"""Import the 19 October workbook and verify its summaries against all 336 calls.

Requires openpyxl. Original workbook and README are read only. Public-ready
exports deliberately omit machine identifiers, UUIDs, commands and local paths.
"""
from pathlib import Path
from collections import Counter, defaultdict
import argparse
import csv
import hashlib
import json
import math
import re
import statistics

import openpyxl

PROJECT = Path(__file__).resolve().parents[1]
EXTRA = {
    'Follow-Your-Emoji-Faster': ('follow_your_emoji_faster', 'ma2026follow'),
    'Hallo-Live': ('hallo_live', 'li2026hallo'),
    'LightningCP': ('lightningcp', 'long2026lightning'),
    'LipForcing': ('lipforcing', 'cho2026lip'),
    'LiveAvatar': ('liveavatar', 'huang2025live'),
    'PersonaLive': ('personalive', 'li2026personalive'),
    'SoulX-LiveAct': ('soulx_liveact', 'zhen2026soulx'),
    'SoulX-FlashTalk': ('soulx_flashtalk', 'shen2026soulxflashtalkrealtimeinfinitestreaming'),
    'SoulX-FlashHead Lite': ('soulx_flashhead_lite', 'yu2026soulx'),
    'SoulX-FlashHead Pro': ('soulx_flashhead_pro', 'yu2026soulx'),
}
TRIAL_FIELDS = ('frames', 'video_fps', 'encoded_width', 'encoded_height',
                'pre_s', 'generation_s', 'post_s', 'load_s', 'call_s',
                'nvml_peak_gib', 'torch_allocated_peak_gib',
                'torch_reserved_peak_gib', 'stage_union_s', 'stage_overlap_s',
                'evaluation_s')
TIMES = ('pre_s', 'generation_s', 'post_s', 'load_s', 'call_s',
         'stage_union_s', 'stage_overlap_s', 'evaluation_s')


def clean(value):
    if value is None:
        return None
    value = str(value)
    value = re.sub(r'/(?:aiboxian|bxai)/[^\s\"\']+', '<LOCAL_PATH>', value)
    return value.strip()


def numeric(value):
    if value in (None, '', 'NR'):
        return None
    if not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'Expected a finite number, got {value!r}')
    return value


def check(actual, expected, label):
    assert actual is not None and math.isclose(actual, expected, rel_tol=1e-8, abs_tol=1e-8), (label, actual, expected)


def stats(values):
    if any(v is None for v in values):
        return dict(values=values, mean=None, median=None, sample_sd=None, minimum=None, maximum=None)
    return dict(values=values, mean=statistics.mean(values), median=statistics.median(values),
                sample_sd=statistics.stdev(values), minimum=min(values), maximum=max(values))


def csv_cell(value):
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    return value


def write_csv(path, rows):
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows({k: csv_cell(v) for k, v in row.items()} for row in rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    book = args.source_dir / 'single_H200_warmup_final_20261019.xlsx'
    wb = openpyxl.load_workbook(book, data_only=True)
    mapping = json.loads((PROJECT / 'measurements/method_mapping.json').read_text())
    conditions = {r[0]: r for r in wb['条件与来源'].iter_rows(min_row=20, values_only=True)}
    details = {r[0]: r for r in wb['测量明细'].iter_rows(min_row=2, values_only=True)}
    trials = []
    grouped = defaultdict(list)
    for r in wb['逐次记录'].iter_rows(min_row=2, values_only=True):
        trial = dict(config_id=r[0], kind=r[1], repeat=r[2],
                     **{k: numeric(v) for k, v in zip(TRIAL_FIELDS, r[3:18])})
        trials.append(trial)
        grouped[r[0]].append(trial)
    assert len(trials) == 336 and len(grouped) == 56
    rows = []
    for sheet, start, cohort in [('单卡 H200 测试', 6, 'main'), ('其他已测方法', 2, 'additional')]:
        for r in wb[sheet].iter_rows(min_row=start, values_only=True):
            n, method = int(r[0]), r[1]
            d, c = details.get(method), conditions.get(method)
            if n <= 46:
                m = mapping[str(n)]
                assert m['method'] == method
                route, cite_key = m['route'], m['cite_key']
            else:
                route, cite_key = 'diffusion', EXTRA[method][1]
            config_id = d[23] if d else EXTRA[method][0]
            all_calls = grouped[config_id]
            for kind in ('warmup', 'measured'):
                assert sorted(t['repeat'] for t in all_calls if t['kind'] == kind) == [1, 2, 3]
            measured = sorted((t for t in all_calls if t['kind'] == 'measured'), key=lambda t: t['repeat'])
            warmup = sorted((t for t in all_calls if t['kind'] == 'warmup'), key=lambda t: t['repeat'])
            summary = {k: stats([t[k] for t in measured]) for k in TIMES}
            for source_idx, field, sd_idx in [(8, 'pre_s', 21), (9, 'generation_s', 22),
                                               (10, 'post_s', 23), (18, 'call_s', 24)]:
                check(r[source_idx], summary[field]['mean'], (method, field, 'mean'))
                check(r[sd_idx], summary[field]['sample_sd'], (method, field, 'sample SD'))
            if numeric(r[13]) is not None:
                check(r[13], summary['load_s']['mean'], (method, 'load_s'))
            else:
                assert summary['load_s']['mean'] is None
            frame_values = [t['frames'] for t in measured]
            assert list(r[28:31]) == frame_values
            if len(set(frame_values)) == 1:
                assert r[4] == frame_values[0]
            else:
                assert str(r[4]) == ' / '.join(map(str, frame_values))
            assert r[19] == r[20] == 3
            for t in measured:
                assert (t['encoded_width'], t['encoded_height']) == (r[14], r[15])
                check(t['pre_s'] + t['generation_s'] + t['post_s'] - t['stage_union_s'],
                      t['stage_overlap_s'], (method, 'phase union'))
                assert t['stage_union_s'] <= t['call_s'] + 1e-8
            check(r[11], max(t['nvml_peak_gib'] for t in measured), (method, 'measured memory'))
            assert r[25] + 1e-8 >= max(t['nvml_peak_gib'] for t in all_calls)
            resident = r[26] == '模型/神经worker常驻'
            mode = 'resident_models_or_worker' if resident else 'reload_each_call'
            original_attention = n <= 46
            context = clean(c[2]) if c else 'Short demo workload supplied in the additional-results sheet; full sampling and precision configuration not included in this delivery.'
            if method == 'LightningCP':
                context += ' Prepared masks are an input prerequisite (delivery README).'
            if method == 'LipForcing':
                context += ' The delivery README specifies a fresh face-cache directory for each call.'
            if method == 'Talker-T2AV':
                context += ' Generation seed 42 is reset after initialization and before motion continuation; all six outputs have 136 frames.'
            row = dict(id=n, config_id=config_id, method=method,
                       method_family='SoulX-FlashHead' if method.startswith('SoulX-FlashHead ') else method,
                       cohort=cohort, route=route, cite_key=cite_key, source_title=r[2], arxiv_id=r[3],
                       status='measured', frames=frame_values[0] if len(set(frame_values)) == 1 else None,
                       frames_per_repeat=frame_values, duration_s=numeric(r[5]) if isinstance(r[5], (int, float)) else None,
                       duration_s_per_repeat=[t['frames'] / t['video_fps'] for t in measured],
                       output_width=r[6], output_height=r[7], encoded_width=r[14], encoded_height=r[15],
                       video_fps=measured[0]['video_fps'],
                       **{k: summary[k]['mean'] for k in TIMES},
                       **{k.replace('_s', '_sd_s'): summary[k]['sample_sd'] for k in TIMES},
                       measured_nvml_peak_gib=r[11], first_warmup_nvml_peak_gib=warmup[0]['nvml_peak_gib'],
                       suite_nvml_peak_gib=r[25], suite_process_s=r[16],
                       torch_allocated_peak_gib=max(t['torch_allocated_peak_gib'] for t in measured),
                       torch_reserved_peak_gib=max(t['torch_reserved_peak_gib'] for t in measured),
                       model_mode=mode, warmup_calls=3, measured_calls=3,
                       attention_backend=clean(r[12]),
                       attention_evidence='Historical execution observations, 2026-10-15; not recaptured during these runs.' if original_attention else 'Source/configuration inspection, 2026-10-19; runtime kernel dispatch not captured.',
                       input_configuration=context,
                       stage_definition=clean(c[1]) if c else 'Implementation-specific synchronized preprocessing, generation and postprocessing; no detailed stage trace supplied for this additional configuration.',
                       code_commit_observed=clean(c[4]) if c else None,
                       torch_version_observed=clean(d[13]) if d else None,
                       flash_attention_version_observed=clean(d[14]) if d else None,
                       xformers_version_observed=clean(d[15]) if d else None,
                       metadata_observed_at=d[21].isoformat() if d and hasattr(d[21], 'isoformat') else None,
                       metadata_scope='Post-run environment/repository inventory; not a benchmark-time capture or a complete instrumentation snapshot.',
                       implementation_status=m['implementation_status'] if n <= 46 else 'Source/configuration metadata only in the supplied workbook',
                       statistics=summary,
                       measured_iterations=measured, warmup_iterations=warmup)
            rows.append(row)
    assert len(rows) == 56 and len({r['method_family'] for r in rows}) == 55
    assert Counter(r['route'] for r in rows) == {'gan': 11, 'diffusion': 20, 'render': 24, 'motion': 1}
    assert Counter(r['model_mode'] for r in rows) == {'resident_models_or_worker': 15, 'reload_each_call': 41}
    def save(name, value):
        (args.output_dir / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    save('h200_results.json', rows)
    save('h200_trials.json', trials)
    write_csv(args.output_dir / 'h200_results.csv', [{k: v for k, v in r.items() if k not in ('statistics', 'measured_iterations', 'warmup_iterations')} for r in rows])
    write_csv(args.output_dir / 'h200_trials.csv', trials)
    save('source_manifest.json', {
        'measurement_date': '2026-10-19', 'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (book, args.source_dir / 'README.md')},
        'inputs_received': ['workbook', 'README'],
        'not_received': ['JSON mentioned by delivery README', 'server-side adapters and raw traces', 'output videos'],
        'verification': 'All 56 summary means/sample SDs, measured NVML maxima, frame sequences and phase unions checked against 336 workbook calls; no GPU inference or independent output-quality review performed.'})
    save('pending_measurements.json', {'revision_date': '2026-10-19', 'recorded_configurations': 56, 'recorded_methods': 55, 'remeasurement': [], 'unmeasured': []})
    print('Verified and imported 56 configurations / 55 methods / 336 calls.')


if __name__ == '__main__':
    main()
