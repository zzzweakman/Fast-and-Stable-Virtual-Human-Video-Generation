"""Build a manuscript in a fresh directory; source files remain untouched.

Usage: python revision/build_pdf.py [--source main.tex]
  [--project /path/to/project] [--portable-tex-root /path/to/portable/tex]
Ordinary installations use pdflatex and bibtex from PATH. The optional portable
root is only an environment fallback, not a manuscript dependency.
"""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import tempfile

p=argparse.ArgumentParser()
p.add_argument("--source",default="main.tex")
p.add_argument("--project",type=Path,default=Path(__file__).resolve().parents[1])
p.add_argument("--portable-tex-root",type=Path)
a=p.parse_args()
project=a.project.resolve(); source=Path(a.source)
out=Path(tempfile.mkdtemp(prefix="vh-build-"+source.stem+"-"))
env=os.environ.copy()
if a.portable_tex_root:
    t=a.portable_tex_root.resolve()
    dist=t/"texlive/usr/share/texlive/texmf-dist"
    debian=t/"texlive/usr/share/texmf"
    env["TEXMFCNF"]=str(t/"tex-config")+":"+str(dist/"web2c")
    env["LD_LIBRARY_PATH"]=str(t/"texlive/usr/lib/x86_64-linux-gnu")+":"+env.get("LD_LIBRARY_PATH","")
    env["TEXFONTMAPS"]=".:"+str(t/"tex-fontmaps")+"//:"+str(debian/"fonts/map")+"//:"+str(dist/"fonts/map")+"//"
    latex=[str(t/"texlive/usr/bin/pdftex"),"-progname=pdflatex","-fmt=pdflatex"]
    bib=[str(t/"texlive/usr/bin/bibtex.original")]
else:
    latex=[shutil.which("pdflatex") or "pdflatex"]
    bib=[shutil.which("bibtex") or "bibtex"]
env["BIBINPUTS"]=str(project)+"//:"
env["BSTINPUTS"]=str(project)+"//:"
print("BUILD_DIR",out,flush=True)
def run(cmd,log,cwd):
    with (out/log).open("x") as f:
        r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
    print(log,"exit",r.returncode,flush=True)
    if r.returncode:
        print((out/log).read_text(errors="replace")[-6500:],flush=True)
        raise SystemExit(r.returncode)
for i in range(1,5):
    run(latex+["-interaction=nonstopmode","-halt-on-error","-file-line-error",f"-output-directory={out}",str(source)],f"latex-{i}.txt",project)
    if i==1 and r"\bibliography{" in (project/source).read_text():
        run(bib+[source.stem],"bibtex.txt",out)
print("PDF",out/source.with_suffix(".pdf").name,flush=True)
log=(out/source.with_suffix(".log").name).read_text(errors="replace")
issues=[s for s in log.splitlines() if any(x in s for x in ["Warning", "Overfull", "Undefined", "Missing character"])]
print("FINAL_LOG_MESSAGES",len(issues),flush=True)
for s in issues: print(s)
